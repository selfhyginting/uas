<?php
$koneksi= mysqli_connect("localhost","root","");
mysqli_select_db($koneksi,"pengunjung");
?>